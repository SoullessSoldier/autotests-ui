import pytest

@pytest.fixture(scope="function")
def function_browser():
    print("Данная фикстура будет запущена на каждый автотест")

@pytest.fixture(scope="class")
def class_browser():
    print("Данная фикстура будет запущена на каждый тестовый класс")

@pytest.fixture(scope="module")
def module_browser():
    print("Данная фикстура будет запущена на каждый модуль python")

@pytest.fixture(scope="session")
def session_browser():
    print("Данная фикстура будет запущена один раз на всю тестовую сессию")


@pytest.fixture
def setup_teardown_example():
    # Подготовка — данный код будет выполнен до начала автотеста
    resource = 'Some resource'
    yield resource # Выполняется автотест
    # Очистка — данный код будет выполнен после завершения автотеста
    print("Teardown: освобождение ресурса")


@pytest.fixture
def setup_teardown():
    # Это часть Setup — код, который выполняется перед тестом
    print("Setup: Инициализация данных или окружения")
    test_data = {"user": "testuser", "password": "testpass"}

    # Это часть Teardown — код, который выполняется после теста
    yield test_data  # Здесь возвращаем данные для теста

    print("Teardown: Очистка данных или окружения")
    # Здесь можно закрыть соединения, удалить временные файлы и т.д.
    # Например, удалить созданные записи в базе данных, если таковые были.

def test_login(setup_teardown):
    # Здесь setup_teardown будет содержать возвращённые данные из фикстуры
    assert setup_teardown["user"] == "testuser"
    assert setup_teardown["password"] == "testpass"


@pytest.fixture
def playwright(): # Инициализируем фикстуру playwright
    return new_playwright()

@pytest.fixture
def chromium(playwright): # Передаем фикстуру playwright
    return playwright.chromium.launch()

def test_user_can_login(chromium):
    chromium.goto("http://localhost:7000/login")

