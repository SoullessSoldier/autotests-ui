import pytest
from playwright.sync_api import expect, sync_playwright

@pytest.fixture
def sample_fixture():
    return {'key': 'value'}

@pytest.fixture
def user_data():
    return {'username': 'test_user', 'email': 'test@example.com'}

@pytest.fixture
def chromium():
    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True)
        yield browser


@pytest.fixture(autouse=True)
def send_analytics_data():
    print('Данная фикстура будет запущена автоматически перед каждым автотестом')


def test_using_fixture(sample_fixture):
    assert sample_fixture['key'] == 'value'


def test_user_email(user_data):
    assert user_data['email'] == 'test@example.com'


def test_user_username(user_data):
    assert user_data['username'] == 'test_user'


def test_user_can_login(chromium):
    chromium.new_page().goto('http://localhost')

def test_1():
    pass
