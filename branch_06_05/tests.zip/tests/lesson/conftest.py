from collections.abc import Generator
import pytest
from playwright.sync_api import sync_playwright, Page

# Page - Импортируем класс страницы, будем использовать его для аннотации типов

@pytest.fixture
def chromium_page() -> Generator[Page, None, None]:
    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True)
        yield browser.new_page()
        browser.close()