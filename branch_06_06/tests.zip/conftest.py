pytest_plugins = (
    'fixtures.browsers',
)