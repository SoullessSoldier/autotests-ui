pytest_plugins = (
    'tests.fixtures.browsers',
    'tests.fixtures.api',
)
