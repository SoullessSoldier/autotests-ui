import pytest

@pytest.fixture
def browser():
    # Логика для инициализации браузера
    pass
