import pytest

@pytest.fixture
def api_client():
    # Возвращаем клиент для работы с API
    pass
